// 文件读取工具 - 使用 FileReader 保证 WebView 兼容性
function readFileAsArrayBuffer(file){
  return new Promise((resolve,reject)=>{
    const fr=new FileReader();
    fr.onload=()=>resolve(fr.result);
    fr.onerror=()=>reject(fr.error||new Error('读取文件失败'));
    fr.readAsArrayBuffer(file);
  });
}
function readFileAsText(file,encoding){
  return new Promise((resolve,reject)=>{
    const fr=new FileReader();
    fr.onload=()=>resolve(fr.result);
    fr.onerror=()=>reject(fr.error||new Error('读取文件失败'));
    fr.readAsText(file,encoding);
  });
}

// 编码检测
function detectEncoding(buf){
  if(buf[0]===0xEF&&buf[1]===0xBB&&buf[2]===0xBF) return 'utf-8-sig';
  if(buf[0]===0xFF&&buf[1]===0xFE) return 'utf-16le';
  if(buf[0]===0xFE&&buf[1]===0xFF) return 'utf-16be';
  if(isValidUTF8(buf)) return 'utf-8';
  return 'gbk';
}
function isValidUTF8(b){
  let i=0;const len=Math.min(b.length,8192);
  while(i<len){
    const c=b[i];
    if(c<0x80){i++;continue}
    if(c>=0xC0&&c<0xE0){if(i+1>=len)return false;if((b[i+1]&0xC0)!==0x80)return false;i+=2}
    else if(c>=0xE0&&c<0xF0){if(i+2>=len)return false;if((b[i+1]&0xC0)!==0x80||(b[i+2]&0xC0)!==0x80)return false;i+=3}
    else if(c>=0xF0&&c<0xF8){if(i+3>=len)return false;if((b[i+1]&0xC0)!==0x80||(b[i+2]&0xC0)!==0x80||(b[i+3]&0xC0)!==0x80)return false;i+=4}
    else return false;
  }
  return true;
}
function decodeText(buf,enc){
  const d=new TextDecoder(enc==='utf-8-sig'?'utf-8':enc,{fatal:false});
  let t=d.decode(buf);
  if(t.charCodeAt(0)===0xFEFF) t=t.slice(1);
  return t;
}

// 章节标题匹配
const CHAPTER_PATTERNS=[
  /^[ \t]{0,4}(?:第\s{0,4}[\d〇零一二两三四五六七八九十百千万壹贰叁肆伍陆柒捌玖拾佰仟]+?\s{0,4}(?:章|节|卷|集|部|篇)[\s\S]{0,30})$/,
  /^[ \t]{0,4}(?:序章|楔子|前言|引子|正文|终章|后记|尾声|番外|简介|文案)[\s\S]{0,20}$/,
  /^[ \t]{0,4}(?:Chapter|CHAPTER)\s+\d+[\s\S]{0,30}$/
];
function isChapterTitle(l){
  const t=l.trim();
  if(!t||t.length>50) return false;
  for(const p of CHAPTER_PATTERNS) if(p.test(t)) return true;
  return false;
}

function splitChapters(text){
  const lines=text.split(/\r\n|\r|\n/);
  const chs=[];
  let title=null,buf=[];
  for(const line of lines){
    if(isChapterTitle(line)&&buf.length>0){
      chs.push({title:title||'开始',content:buf.join('\n').trim()});
      title=line.trim();buf=[];
    }else{
      if(title===null&&line.trim()) buf.push(line);
      else if(title!==null) buf.push(line);
    }
  }
  if(buf.length>0) chs.push({title:title||'开始',content:buf.join('\n').trim()});
  if(chs.length<=1) return splitBySize(text,5000);
  return chs;
}
function splitBySize(text,sz){
  const chs=[];let i=0,n=1;
  while(i<text.length){
    chs.push({title:`第${n}节`,content:text.slice(i,i+sz).trim()});
    i+=sz;n++;
  }
  if(chs.length===0) chs.push({title:'正文',content:text.trim()});
  return chs;
}
function splitParagraphs(c){
  return c.split(/\n+/).map(p=>p.trim()).filter(p=>p.length>0);
}

async function parseTXT(file){
  const buf=await readFileAsArrayBuffer(file);
  const u8=new Uint8Array(buf);
  const enc=detectEncoding(u8);
  const text=decodeText(u8,enc);
  const chs=splitChapters(text);
  return{
    title:file.name.replace(/\.txt$/i,''),
    author:'未知',
    format:'txt',
    chapters:chs.map((ch,i)=>({title:ch.title,paragraphs:splitParagraphs(ch.content),index:i}))
  };
}

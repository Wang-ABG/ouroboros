const DB_NAME='NovelReaderDB';
const DB_VERSION=1;
let db=null;

function openDB(){
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onerror=()=>reject(req.error);
    req.onsuccess=()=>{
      db=req.result;
      resolve(db);
    };
    req.onupgradeneeded=(e)=>{
      const d=e.target.result;
      if(!d.objectStoreNames.contains('books')){
        d.createObjectStore('books',{keyPath:'id'});
      }
      if(!d.objectStoreNames.contains('chapters')){
        const s=d.createObjectStore('chapters',{keyPath:['bookId','index']});
        s.createIndex('bookId','bookId',{unique:false});
      }
      if(!d.objectStoreNames.contains('comments')){
        const s=d.createObjectStore('comments',{keyPath:'id',autoIncrement:true});
        s.createIndex('bookId','bookId',{unique:false});
        s.createIndex('para',['bookId','chapterIndex','paraIndex'],{unique:false});
      }
      if(!d.objectStoreNames.contains('progress')){
        d.createObjectStore('progress',{keyPath:'bookId'});
      }
      if(!d.objectStoreNames.contains('bookmarks')){
        const s=d.createObjectStore('bookmarks',{keyPath:'id',autoIncrement:true});
        s.createIndex('bookId','bookId',{unique:false});
      }
    };
  });
}

function tx(store,mode){
  return db.transaction(store,mode).objectStore(store);
}

async function dbAddBook(b){
  return new Promise((resolve,reject)=>{
    const q=tx('books','readwrite').add(b);
    q.onsuccess=()=>resolve(b.id);
    q.onerror=()=>reject(q.error);
  });
}

async function dbGetAllBooks(){
  return new Promise((resolve,reject)=>{
    const q=tx('books','readonly').getAll();
    q.onsuccess=()=>resolve(q.result||[]);
    q.onerror=()=>reject(q.error);
  });
}

async function dbGetBook(id){
  return new Promise((resolve,reject)=>{
    const q=tx('books','readonly').get(id);
    q.onsuccess=()=>resolve(q.result);
    q.onerror=()=>reject(q.error);
  });
}

async function dbDeleteBook(id){
  return new Promise((resolve,reject)=>{
    const t=db.transaction(['books','chapters','comments','progress','bookmarks'],'readwrite');
    t.objectStore('books').delete(id);
    const ci=t.objectStore('chapters').index('bookId');
    ci.openCursor(IDBKeyRange.only(id)).onsuccess=(e)=>{
      const c=e.target.result;
      if(c){c.delete();c.continue();}
    };
    const mi=t.objectStore('comments').index('bookId');
    mi.openCursor(IDBKeyRange.only(id)).onsuccess=(e)=>{
      const c=e.target.result;
      if(c){c.delete();c.continue();}
    };
    t.objectStore('progress').delete(id);
    const bi=t.objectStore('bookmarks').index('bookId');
    bi.openCursor(IDBKeyRange.only(id)).onsuccess=(e)=>{
      const c=e.target.result;
      if(c){c.delete();c.continue();}
    };
    t.oncomplete=()=>resolve();
    t.onerror=()=>reject(t.error);
  });
}

async function dbAddChapters(cs){
  return new Promise((resolve,reject)=>{
    const s=tx('chapters','readwrite');
    cs.forEach(c=>s.put(c));
    s.transaction.oncomplete=()=>resolve();
    s.transaction.onerror=()=>reject(s.transaction.error);
  });
}

async function dbGetChapter(b,i){
  return new Promise((resolve,reject)=>{
    const q=tx('chapters','readonly').get([b,i]);
    q.onsuccess=()=>resolve(q.result);
    q.onerror=()=>reject(q.error);
  });
}

async function dbAddComment(c){
  return new Promise((resolve,reject)=>{
    const q=tx('comments','readwrite').add(c);
    q.onsuccess=()=>resolve(q.result);
    q.onerror=()=>reject(q.error);
  });
}

async function dbGetCommentsByParagraph(b,c,p){
  return new Promise((resolve,reject)=>{
    const idx=tx('comments','readonly').index('para');
    const q=idx.getAll(IDBKeyRange.only([b,c,p]));
    q.onsuccess=()=>resolve(q.result||[]);
    q.onerror=()=>reject(q.error);
  });
}

async function dbGetCommentsByChapter(b,c){
  return new Promise((resolve,reject)=>{
    const store=tx('comments','readonly');
    const idx=store.index('bookId');
    const res=[];
    idx.openCursor(IDBKeyRange.only(b)).onsuccess=(e)=>{
      const cur=e.target.result;
      if(cur){
        if(cur.value.chapterIndex===c){
          res.push(cur.value);
        }
        cur.continue();
      } else {
        resolve(res);
      }
    };
  });
}

async function dbGetCommentCounts(b,c){
  const all=await dbGetCommentsByChapter(b,c);
  const m={};
  all.forEach(x=>{
    m[x.paraIndex]=(m[x.paraIndex]||0)+1;
  });
  return m;
}

async function dbSaveProgress(b,c,s){
  return new Promise((resolve,reject)=>{
    const q=tx('progress','readwrite').put({bookId:b,chapterIndex:c,scrollTop:s,updatedAt:Date.now()});
    q.onsuccess=()=>resolve();
    q.onerror=()=>reject(q.error);
  });
}

async function dbGetProgress(b){
  return new Promise((resolve,reject)=>{
    const q=tx('progress','readonly').get(b);
    q.onsuccess=()=>resolve(q.result);
    q.onerror=()=>reject(q.error);
  });
}

async function dbAddBookmark(bm){
  return new Promise((resolve,reject)=>{
    const q=tx('bookmarks','readwrite').add(bm);
    q.onsuccess=()=>resolve(q.result);
    q.onerror=()=>reject(q.error);
  });
}
